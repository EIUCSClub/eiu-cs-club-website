Dopetrope by HTML5 UP
html5up.net | @ajlkn
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)


A spiffy new blog/magazine style responsive site template with a flat/minimal
design aesthetic.

Demo images* are courtesy of the incredibly talented Janine Pring aka Dreametry Doodle.
See more of her amazing work (and her awesome t-shirt line) @ dreametrydoodle.com

(* = Not included! Only meant for use with my own on-site demo, so please do NOT download
and/or use any of Janine's work without her explicit permission!)

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

AJ
aj@lkn.io | @ajlkn


Credits:

	Demo Images:
		Dreametry Doodle (dreametrydoodle.com)

	Icons:
		Font Awesome (fontawesome.io)

	Other:
		jQuery (jquery.com)
		Responsive Tools (github.com/ajlkn/responsive-tools)